#!/bin/bash
echo 'Importing n8n flows...'